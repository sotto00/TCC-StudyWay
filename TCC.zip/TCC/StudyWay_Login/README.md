# StudyWay — Front-end React

Fluxo inicial (onboarding) criado com React e Vite. A navegação superior e os botões permitem visualizar as quatro etapas.

## Executar

```bash
npm install
npm run dev
```

## Organização

- `src/App.jsx`: controla a etapa selecionada.
- `src/data/onboardingSteps.js`: textos, rótulos e configuração das telas.
- `src/components/OnboardingScreen.jsx`: componente reutilizável das telas.
- `src/components/Icons.jsx`: ícones SVG, sem imagens externas.
- `src/styles.css`: estilos globais e responsividade.

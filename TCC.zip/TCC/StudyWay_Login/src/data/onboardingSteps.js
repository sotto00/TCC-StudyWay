import { GraduationIcon, ProgressIcon, TrophyIcon } from '../components/Icons'

export const onboardingSteps = [
  { id: 'home', navigationLabel: 'Início', type: 'welcome', buttonLabel: 'Próximo' },
  { id: 'purpose', navigationLabel: 'Introdução 1', title: 'Estude com propósito', description: 'Planos personalizados para o ENEM, vestibulares e concursos com base no seu desempenho.', Icon: GraduationIcon, buttonLabel: 'Próximo' },
  { id: 'progress', navigationLabel: 'Introdução 2', title: 'Acompanhe seu progresso', description: 'Confira seu desempenho nos estudos e descubra onde você pode evoluir ainda mais.', Icon: ProgressIcon, buttonLabel: 'Próximo' },
  { id: 'consistency', navigationLabel: 'Introdução 3', title: 'Mantenha a sequência', description: 'Metas diárias, conquistas e streaks para manter a motivação e alcançar sua aprovação.', Icon: TrophyIcon, buttonLabel: 'Começar agora' },
]

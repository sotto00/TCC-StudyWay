import { useState } from 'react'
import { AuthScreen } from './components/AuthScreen'
import { OnboardingScreen } from './components/OnboardingScreen'
import { onboardingSteps } from './data/onboardingSteps'

function App() {
  const [currentStep, setCurrentStep] = useState(0)
  const [screen, setScreen] = useState('onboarding')
  const [authMode, setAuthMode] = useState('login')

  const goToNextStep = () => {
    if (currentStep === onboardingSteps.length - 1) {
      setScreen('auth')
      return
    }
    setCurrentStep((step) => step + 1)
  }

  if (screen === 'auth') return <AuthScreen mode={authMode} onModeChange={setAuthMode} />

  return <main className="app-shell"><OnboardingScreen step={onboardingSteps[currentStep]} onContinue={goToNextStep} /></main>
}

export default App

import { useState } from 'react'

function BookMark() {
  return <svg className="auth-book" viewBox="0 0 48 38" aria-hidden="true"><path d="M2 5h19a4 4 0 0 1 4 4v25a4 4 0 0 0-4-4H2Zm44 0H27a4 4 0 0 0-4 4v25a4 4 0 0 1 4-4h19Z" /><path d="M8 10h11M8 16h11M29 10h11M29 16h11" /></svg>
}

export function AuthScreen({ mode, onModeChange }) {
  const isLogin = mode === 'login'
  const [message, setMessage] = useState('')
  const submit = (event) => {
    event.preventDefault()
    setMessage(isLogin ? 'Acesso enviado com sucesso.' : 'Cadastro enviado com sucesso.')
  }

  return <main className="auth-page">
    <section className="auth-header">
      <div className="auth-brand"><BookMark /><span>Study<span>Way</span></span></div>
      <h1>{isLogin ? 'Bem-vindo de volta!' : 'Crie sua conta'}</h1>
      <p>{isLogin ? 'Continue sua jornada de estudos' : 'Comece sua jornada rumo à aprovação'}</p>
    </section>
    <section className="auth-content" aria-label={isLogin ? 'Entrar' : 'Cadastrar'}>
      <div className="auth-card">
        <div className="auth-tabs" role="tablist" aria-label="Acesso à conta">
          <button className={isLogin ? 'is-selected' : ''} type="button" role="tab" aria-selected={isLogin} onClick={() => { onModeChange('login'); setMessage('') }}>Entrar</button>
          <button className={!isLogin ? 'is-selected' : ''} type="button" role="tab" aria-selected={!isLogin} onClick={() => { onModeChange('signup'); setMessage('') }}>Cadastrar</button>
        </div>
        <form className="auth-form" onSubmit={submit}>
          {!isLogin && <label>Nome completo<input type="text" placeholder="Digite seu nome..." required /></label>}
          <label>E-mail<input type="email" placeholder="Digite seu email..." autoComplete="email" required /></label>
          <label className="password-label">Senha{isLogin && <button type="button" className="forgot-password">Esqueci a senha</button>}<input type="password" placeholder="Digite sua senha..." autoComplete={isLogin ? 'current-password' : 'new-password'} required /></label>
          {message && <p className="auth-message" role="status">{message}</p>}
          <button className="auth-submit" type="submit">{isLogin ? 'Entrar' : 'Criar conta grátis'}</button>
        </form>
        <div className="or-divider"><span>ou continue com</span></div>
        <div className="social-options"><button type="button"><b>G</b> Google</button><button type="button"><b className="apple">●</b> Apple</button></div>
      </div>
    </section>
  </main>
}

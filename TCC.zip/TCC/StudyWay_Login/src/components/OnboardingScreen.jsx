import { StudyWayLogo } from './Icons'

export function OnboardingScreen({ step, onContinue }) {
  if (step.type === 'welcome') return <section className="onboarding-screen welcome-screen" aria-labelledby="welcome-title"><div className="welcome-brand" id="welcome-title"><StudyWayLogo /><p><strong>Study</strong><span>Way</span></p></div><button className="primary-button" type="button" onClick={onContinue}>{step.buttonLabel}</button></section>
  const { Icon } = step
  return <section className="onboarding-screen content-screen" aria-labelledby={`${step.id}-title`}><div className="onboarding-content"><div className="icon-card"><Icon /></div><div className="onboarding-copy"><h1 id={`${step.id}-title`}>{step.title}</h1><p>{step.description}</p></div></div><button className="primary-button" type="button" onClick={onContinue}>{step.buttonLabel}</button></section>
}

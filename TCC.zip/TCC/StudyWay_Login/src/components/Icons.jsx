import studyWayImage from '../assets/img_studyway.png'

export function StudyWayLogo() {
  return <img className="studyway-logo" src={studyWayImage} alt="StudyWay" />
}

export function GraduationIcon() { return <svg viewBox="0 0 100 100" aria-hidden="true"><path d="m22 32 28-13 28 13-28 13Z M31 37v15c11 9 27 9 38 0V37 M73 36v14" /><path d="M24 65c7-7 15-6 22 0l8 7 21-20M22 65l11 14 12-10" /></svg> }
export function ProgressIcon() { return <svg viewBox="0 0 100 100" aria-hidden="true"><path d="M20 72V57l13-13 12 12 23-24M59 32h14v14" /><path d="M25 72V62M40 72V54M55 72V48M70 72V35" /></svg> }
export function TrophyIcon() { return <svg viewBox="0 0 100 100" aria-hidden="true"><path d="M30 23h40v21c0 16-10 25-20 25S30 60 30 44ZM30 30H19v9c0 10 5 15 15 15M70 30h11v9c0 10-5 15-15 15M50 69v12M37 83h26" /><path d="m50 37 4 8 9 1-7 6 2 9-8-4-8 4 2-9-7-6 9-1Z" /></svg> }
